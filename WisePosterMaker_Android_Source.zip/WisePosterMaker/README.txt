WISE POSTER MAKER — ANDROID STARTER PROJECT

What this version does:
- Android app shell with a product-poster editor.
- Product name, price, badge, tagline and store details are editable.
- Select a product photo from the phone.
- Live 1080 x 1350 poster preview.
- Save the generated PNG to Pictures/WisePosterMaker on Android.
- Wise Supermart logo cropped from the reference poster supplied in the chat.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the WisePosterMaker folder.
4. Allow Gradle sync to finish. Use JDK 17 and Android SDK 35 (Android Studio can install missing SDK components).
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Transfer it to your Android phone and install it.
   You may need to allow installation from that file manager.

Important:
- This is a starter Android Studio source project, not a compiled APK.
- AI-generated backgrounds/templates and cloud sync are not included yet.
- Product photos are processed locally in the app; no account or backend is needed for this starter.
- For a production release, add app signing, privacy policy, more templates, and test on the target Android device.
